package com.example.ellisamualifah_32602100041

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class activity_abot : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_abot)
    }
}