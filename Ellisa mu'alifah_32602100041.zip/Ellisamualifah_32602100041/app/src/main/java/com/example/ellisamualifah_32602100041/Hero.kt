package com.example.ellisamualifah_32602100041

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class Hero(
    val name: String,
    val description: String,
    val photo: Int,
    val keterangan: String, // tambahkan ini
) : Parcelable
